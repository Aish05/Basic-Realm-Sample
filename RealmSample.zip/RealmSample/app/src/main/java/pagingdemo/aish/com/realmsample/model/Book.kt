package pagingdemo.aish.com.realmsample.model

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey

data class Book(@PrimaryKey
                private val id : Int,
                private val title : String,
                private val description : String,
                private val author : String,
                private val imageUrl : String) : RealmObject()